# Bot SSH Auto Instalador

Este repositorio instala automáticamente un bot de Telegram integrado con Mercado Pago y generación de accesos SSH.

## Ejecución rápida
```bash
bash <(curl -s https://raw.githubusercontent.com/TU_USUARIO_GITHUB/bot_ssh_installer/main/instalar_bot_ssh.sh)
```

> Reemplaza los tokens en el archivo `instalar_bot_ssh.sh` antes de usar.
